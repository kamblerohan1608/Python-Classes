
import re



# Q .write a program to find a sqquence of lower case letters joint with an underscore

#test = "Hello_world , hi_there , Is_this_ok , thats_me , catch_me"

# def lowercase_function(text):
#     ptr = r'\b[a-z]+_[a-z]+\b'
#     x = re.findall(ptr,text)
#     return x

# text = input("Enter the test line here : ")
# print(lowercase_function(text))



# Q .write a program that matches a string that has an 'a' followed by anything and ends with 'b'

# test = "aaaaaaaaaaa here is the string bbbbbbbbbbb"

# def a_b(text):
#     prt = r'\Aa[a-zA-Z0-9 *]+b\Z'
#     x = re.findall(prt,text)
#     return x

# text = input("Enter the test line here : ")
# print(a_b(text))



# Q .write a python program that matches a word wich contains z

# test = " Crazy syncronization camel puzzle signes "

# def z_word(text):    
#     ptr = r'[a-zA-z]+z+[a-zA-z]+'
#     x = re.findall(ptr,text)
#     return x
# text = input("Enter the test line here : ")
# print(z_word(text))



